import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Standalone output for Hostinger Cloud (PM2 deployment)
  output: "standalone",

  // No image optimization needed for this app
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
